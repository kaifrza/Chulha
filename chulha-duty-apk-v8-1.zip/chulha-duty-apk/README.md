# Chulha Duty (Android APK)

5 chefs, 2 chulhas. Duty rotation, off days, away chefs with swaps, kitchen hisaab, chef photos and a daily duty reminder. Built into an APK by GitHub Actions (Capacitor), so no laptop is needed.

## Get the APK (phone only)
1. Create a **private** GitHub repository (the signing key is inside the project).
2. Upload **two things** to the repo: the file `.github/workflows/build-apk.yml` (once) and this project zip. No need to unzip anything.
3. The build starts by itself on every push. Open **Actions**, then the latest run. When it is green, the summary shows the download link.
4. Download `ChulhaDuty-buildN.apk` from the **Releases** page (a direct APK, no extra zip) and install it.
5. For the next version just upload the new zip. The newest zip in the repo is always the one that gets built.
6. If the build fails, open the run summary, copy the "Error text to copy" box and send it to Claude.

Every build is signed with the same key (`release.keystore`), so a new APK installs **over** the old one and keeps all data. Never uninstall the app to update it: uninstalling deletes the hisaab. Back up first (Settings, Back up & share).

## Duty algorithm
- Pairs repeat: 1-2, 3-4, 5-1, 2-3, 4-5 (Abdush Shakoor 1, Laique 2, Armoghan 3, Tousif 4, Kaif 5). Each chef cooks 4 days in 10.
- Off days (and weekly off) skip cooking and do not move the rotation.
- A chef who is away is replaced by the next number who is free and not already in that day's pair. When the chef is back, he takes the cover's next slot.
- Two or three chefs away work the same way. One chef free cooks alone. Nobody free is treated as an off day.

## Hisaab
- Money is handled in whole paise, so shares always add up exactly.
- Every expense has "Who ate?" (default: chefs not away that day). The cost is split equally among them. Payers can be anyone.
- Settlements on "This day" only touch that day. "All time" settlements stay separate from daily accounts.

## Data
Saved in the app's private storage on the phone (two alternating files, so a crash cannot corrupt the last good copy). Photos are stored separately. Use **Back up & share** to send a backup to WhatsApp, Drive or Files, and **Restore backup** to load it again.

## Files
- `www/` the app (HTML, CSS, JS, fonts)
- `assets/` icon and splash source images
- `scripts/` Android patch and signing steps used by the workflow
- `tests/core.test.js` logic tests (run automatically before every build)
