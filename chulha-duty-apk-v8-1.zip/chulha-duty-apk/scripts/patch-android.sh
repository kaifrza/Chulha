#!/usr/bin/env bash
# Runs after "npx cap add android": permissions, SDK level, version, notification icon.
set -euo pipefail
MAIN=android/app/src/main

# notification permission + exact alarms (daily duty reminder)
sed -i 's#</manifest>#    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n    <uses-permission android:name="android.permission.USE_EXACT_ALARM" />\n</manifest>#' "$MAIN/AndroidManifest.xml"

# targetSdk 34: keeps the web view below the status bar on Android 15+ (no forced edge-to-edge)
if grep -q "targetSdkVersion" android/variables.gradle; then
  sed -i -E 's/targetSdkVersion *= *[0-9]+/targetSdkVersion = 34/' android/variables.gradle
fi

# every build gets a higher version so it installs over the previous one
RUN="${GITHUB_RUN_NUMBER:-1}"
sed -i -E "s/versionCode [0-9]+/versionCode ${RUN}/; s/versionName \"[^\"]*\"/versionName \"1.${RUN}\"/" android/app/build.gradle

# notification small icon (white flame silhouette)
mkdir -p "$MAIN/res/drawable"
cp native/res/drawable/ic_stat_flame.xml "$MAIN/res/drawable/ic_stat_flame.xml"

echo "patched android project (run ${RUN})"
