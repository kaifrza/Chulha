'use strict';
const assert = require('assert');
const C = require('../www/core.js');

const names = (r) => r.pair.map((i) => C.CHEFS[i]);
const D = (iso) => C.dayNum(iso);
let passed = 0;
function t(name, fn) { fn(); passed++; console.log('ok  ' + name); }

const base = { startDate: '2026-10-02', startPair: 0, weeklyOff: [], offDays: [], aways: [] };

t('base rotation: 5 pairs repeat, 4 turns per chef in 10 days', () => {
  const e = C.createEngine(base);
  const count = [0, 0, 0, 0, 0];
  for (let i = 0; i < 10; i++) e.dutyFor(D('2026-10-02') + i).pair.forEach((c) => count[c]++);
  assert.deepStrictEqual(count, [4, 4, 4, 4, 4]);
  assert.deepStrictEqual(e.dutyFor(D('2026-10-02')).pair, [0, 1]);
  assert.deepStrictEqual(e.dutyFor(D('2026-10-03')).pair, [2, 3]);
  assert.deepStrictEqual(e.dutyFor(D('2026-10-04')).pair, [4, 0]);
  assert.deepStrictEqual(e.dutyFor(D('2026-10-07')).pair, [0, 1]);
  assert.strictEqual(e.dutyFor(D('2026-10-02')).label, 1);
  assert.strictEqual(e.dutyFor(D('2026-10-11')).label, 10);
});

t('user example: 4 (Tousif) absent -> 5 (Kaif) covers; next day Tousif takes Kaif slot', () => {
  const e = C.createEngine(Object.assign({}, base, { aways: [{ chef: 3, from: '2026-10-03', to: '2026-10-03' }] }));
  assert.deepStrictEqual(names(e.dutyFor(D('2026-10-03'))), ['Armoghan', 'Kaif']);
  assert.deepStrictEqual(names(e.dutyFor(D('2026-10-04'))), ['Tousif', 'Abdush Shakoor']);
  assert.strictEqual(e.dutyFor(D('2026-10-04')).slots[0].note.type, 'repay');
  // after payback the rotation is back to normal
  assert.deepStrictEqual(e.dutyFor(D('2026-10-05')).pair, [1, 2]);
  assert.deepStrictEqual(e.debtsAt(D('2026-10-04')), []);
});

t('user example: 5 absent, 1 already in pair -> 2 covers; 5 later replaces 2', () => {
  const e = C.createEngine(Object.assign({}, base, { aways: [{ chef: 4, from: '2026-10-04', to: '2026-10-04' }] }));
  assert.deepStrictEqual(names(e.dutyFor(D('2026-10-04'))), ['Laique', 'Abdush Shakoor']);
  // 2 next slot is 2026-10-05 (pair 2-3 = Laique + Armoghan): Kaif replaces Laique
  assert.deepStrictEqual(names(e.dutyFor(D('2026-10-05'))), ['Kaif', 'Armoghan']);
});

t('debt stays pending while the absent chef is still away', () => {
  const e = C.createEngine(Object.assign({}, base, { aways: [{ chef: 3, from: '2026-10-03', to: '2026-10-05' }] }));
  assert.deepStrictEqual(e.debtsAt(D('2026-10-03')), [{ owner: 4, by: 3 }]);
  // Oct 4: Kaif's slot, Tousif still away -> Kaif cooks normally, debt remains
  assert.deepStrictEqual(names(e.dutyFor(D('2026-10-04'))), ['Kaif', 'Abdush Shakoor']);
  assert.deepStrictEqual(e.debtsAt(D('2026-10-04')), [{ owner: 4, by: 3 }]);
});

t('two chefs of the same pair absent -> two different covers, two swaps', () => {
  const e = C.createEngine(Object.assign({}, base, {
    aways: [{ chef: 0, from: '2026-10-02', to: '2026-10-02' }, { chef: 1, from: '2026-10-02', to: '2026-10-02' }]
  }));
  const r = e.dutyFor(D('2026-10-02'));
  assert.strictEqual(new Set(r.pair).size, 2);
  r.pair.forEach((c) => assert.ok(c !== 0 && c !== 1));
  assert.strictEqual(e.debtsAt(D('2026-10-02')).length, 2);
});

t('only one chef free -> cooks alone; nobody free -> auto off day without advancing rotation', () => {
  const four = [0, 1, 2, 3].map((c) => ({ chef: c, from: '2026-10-02', to: '2026-10-02' }));
  const e = C.createEngine(Object.assign({}, base, { aways: four }));
  assert.deepStrictEqual(e.dutyFor(D('2026-10-02')).pair, [4]);
  const all = [0, 1, 2, 3, 4].map((c) => ({ chef: c, from: '2026-10-02', to: '2026-10-02' }));
  const e2 = C.createEngine(Object.assign({}, base, { aways: all }));
  assert.strictEqual(e2.dutyFor(D('2026-10-02')).off, true);
  assert.deepStrictEqual(e2.dutyFor(D('2026-10-03')).pair, [0, 1]);
});

t('off day: nobody cooks and the rotation does not advance', () => {
  const e = C.createEngine(Object.assign({}, base, { offDays: [{ from: '2026-10-03', to: '2026-10-04', reason: 'Trip' }] }));
  assert.strictEqual(e.dutyFor(D('2026-10-03')).off, true);
  assert.strictEqual(e.dutyFor(D('2026-10-04')).reason, 'Trip');
  assert.deepStrictEqual(e.dutyFor(D('2026-10-05')).pair, [2, 3]);
});

t('weekly off (Friday = 5) is skipped', () => {
  const e = C.createEngine(Object.assign({}, base, { weeklyOff: [5] }));
  assert.strictEqual(e.dutyFor(D('2026-10-02')).off, true); // 2 Oct 2026 is a Friday
  assert.deepStrictEqual(e.dutyFor(D('2026-10-03')).pair, [0, 1]);
});

t('fairness: with swaps every chef still ends with a balanced count over a long run', () => {
  const aways = [];
  for (let i = 0; i < 40; i += 7) aways.push({ chef: (i / 7) % 5, from: C.isoOf(D('2026-10-02') + i), to: C.isoOf(D('2026-10-02') + i + 1) });
  const e = C.createEngine(Object.assign({}, base, { aways }));
  const count = [0, 0, 0, 0, 0];
  for (let i = 0; i < 200; i++) e.dutyFor(D('2026-10-02') + i).pair.forEach((c) => count[c]++);
  const max = Math.max.apply(null, count), min = Math.min.apply(null, count);
  assert.ok(max - min <= 3, 'counts ' + count.join(','));
});

t('accounting: exact paise, sums to zero, equal split', () => {
  const ex = [{ id: 'a', date: '2026-10-03', payments: [{ chef: 4, items: [{ label: 'x', amount: 100.03 }] }, { chef: 1, items: [{ label: 'y', amount: 50 }] }] }];
  const bal = C.balancesFor(ex, []);
  assert.strictEqual(bal.reduce((s, b) => s + b.balanceP, 0), 0);
  assert.strictEqual(bal.reduce((s, b) => s + Math.round(b.share * 100), 0), 15003);
  assert.strictEqual(bal[4].paid, 100.03);
});

t('accounting: only participants share the cost (4 of 5)', () => {
  const ex = [{ id: 'a', date: '2026-10-03', participants: [0, 1, 2, 4], payments: [{ chef: 0, items: [{ label: 'x', amount: 400 }] }] }];
  const bal = C.balancesFor(ex, []);
  assert.strictEqual(bal[3].share, 0);
  assert.strictEqual(bal[3].balanceP, 0);
  assert.strictEqual(bal[0].balanceP, 30000);
  [1, 2, 4].forEach((i) => assert.strictEqual(bal[i].balanceP, -10000));
});

t('accounting: payer who did not eat is repaid fully', () => {
  const ex = [{ id: 'a', date: '2026-10-03', participants: [1, 2], payments: [{ chef: 3, items: [{ label: 'x', amount: 100 }] }] }];
  const bal = C.balancesFor(ex, []);
  assert.strictEqual(bal[3].balanceP, 10000);
  assert.strictEqual(bal[1].balanceP + bal[2].balanceP, -10000);
});

t('settlement suggestions clear every balance', () => {
  const ex = [{ id: 'a', date: '2026-10-03', participants: [0, 1, 2, 4], payments: [{ chef: 4, items: [{ label: 'x', amount: 333.33 }] }] }];
  let bal = C.balancesFor(ex, []);
  const sug = C.makeSuggestions(bal);
  const st = sug.map((s, i) => ({ id: 's' + i, date: '2026-10-03', scope: 'day', from: s.from, to: s.to, amount: s.amount }));
  bal = C.balancesFor(ex, st);
  bal.forEach((b) => assert.strictEqual(b.balanceP, 0));
});

t('sanitize: legacy expenses mapped, bad records skipped, ids made unique, participants default to all', () => {
  const raw = {
    expenses: [
      { id: 'x', date: '2026-10-03', payer: 2, amount: 90, note: 'Sabzi' },
      { id: 'x', date: '2026-10-04', payments: [{ chef: 1, items: [{ label: 'a', amount: 10 }] }] },
      { date: 'bad', payments: [] },
      { date: '2026-10-05', amount: 5 }
    ],
    settlements: [{ date: '2026-10-03', from: 1, to: 1, amount: 5 }, { date: '2026-10-03', from: null, to: 2, amount: 5 }, { date: '2026-10-03', from: 1, to: 2, amount: 5 }],
    startPair: 9, theme: 'weird', weeklyOff: [1, 1, 9, 'x']
  };
  const r = C.sanitizeState(raw);
  assert.strictEqual(r.state.expenses.length, 2);
  assert.notStrictEqual(r.state.expenses[0].id, r.state.expenses[1].id);
  assert.strictEqual(r.state.expenses[0].payments[0].chef, 2);
  assert.strictEqual(r.state.expenses[0].participants.length, 5);
  assert.strictEqual(r.state.settlements.length, 1);
  assert.ok(r.state.settlements[0].id);
  assert.strictEqual(r.state.startPair, 0);
  assert.strictEqual(r.state.theme, 'system');
  assert.deepStrictEqual(r.state.weeklyOff, [1]);
  assert.strictEqual(r.skipped, 4);
});

t('sanitize: ranges are normalised, open-ended away allowed', () => {
  const r = C.sanitizeState({
    offDays: [{ from: '2026-10-09', to: '2026-10-05' }],
    aways: [{ chef: 3, from: '2026-10-05', to: null }, { chef: 7, from: '2026-10-05' }]
  });
  assert.deepStrictEqual([r.state.offDays[0].from, r.state.offDays[0].to], ['2026-10-05', '2026-10-09']);
  assert.strictEqual(r.state.aways.length, 1);
  assert.strictEqual(r.state.aways[0].to, null);
});

t('photos: only small jpeg data URLs survive', () => {
  const ok = 'data:image/jpeg;base64,/9j/4AAQSkZJRg==';
  const out = C.sanitizePhotos({ 0: ok, 1: 'javascript:alert(1)', 2: 'data:image/svg+xml;base64,AAAA', 9: ok });
  assert.deepStrictEqual(Object.keys(out), ['0']);
});

t('performance: 20000-day simulation is fast', () => {
  const e = C.createEngine(Object.assign({}, base, { aways: [{ chef: 2, from: '2026-10-10', to: '2026-12-10' }] }));
  const s = Date.now();
  e.dutyFor(D('2026-10-02') + 19000);
  assert.ok(Date.now() - s < 1500);
});

console.log('\n' + passed + ' tests passed');
