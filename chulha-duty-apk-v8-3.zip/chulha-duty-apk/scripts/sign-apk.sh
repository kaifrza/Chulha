#!/usr/bin/env bash
# Signs the release APK with the repo keystore, so every build can update the one installed on the phone.
set -euo pipefail
BT="$(ls -d "${ANDROID_HOME}"/build-tools/* | sort -V | tail -1)"
UNSIGNED="$(ls android/app/build/outputs/apk/release/*.apk | head -1)"
mkdir -p out
"$BT/zipalign" -f -p 4 "$UNSIGNED" out/aligned.apk
"$BT/apksigner" sign \
  --ks release.keystore --ks-key-alias chulha \
  --ks-pass pass:chulha-duty-2026 --key-pass pass:chulha-duty-2026 \
  --out out/ChulhaDuty.apk out/aligned.apk
"$BT/apksigner" verify out/ChulhaDuty.apk
rm -f out/aligned.apk out/*.idsig
ls -l out
