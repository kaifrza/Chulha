#!/usr/bin/env bash
# Runs after "npx cap add android": permissions, version, status bar behaviour, notification icon.
set -euo pipefail
MAIN=android/app/src/main

# notification permission + exact alarms (daily duty reminder)
sed -i 's#</manifest>#    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n    <uses-permission android:name="android.permission.USE_EXACT_ALARM" />\n</manifest>#' "$MAIN/AndroidManifest.xml"

# Status bar: keep the app below the system bars (no forced edge-to-edge on Android 15+).
# The theme opt-out is the main fix; adjustMarginsForEdgeToEdge in capacitor.config.json is the fallback.
STYLES="$MAIN/res/values/styles.xml"
if [ -f "$STYLES" ] && ! grep -q "windowOptOutEdgeToEdgeEnforcement" "$STYLES"; then
  sed -i '/<style name="AppTheme/a\        <item name="android:windowOptOutEdgeToEdgeEnforcement">true</item>' "$STYLES"
  echo "edge-to-edge opt-out added to $(grep -c windowOptOutEdgeToEdgeEnforcement "$STYLES") theme(s)"
else
  echo "styles.xml not found or already patched"
fi

# every build gets a higher version so it installs over the previous one
RUN="${GITHUB_RUN_NUMBER:-1}"
sed -i -E "s/versionCode [0-9]+/versionCode ${RUN}/; s/versionName \"[^\"]*\"/versionName \"1.${RUN}\"/" android/app/build.gradle

# notification small icon (white flame silhouette)
mkdir -p "$MAIN/res/drawable"
cp native/res/drawable/ic_stat_flame.xml "$MAIN/res/drawable/ic_stat_flame.xml"

echo "patched android project (run ${RUN})"
