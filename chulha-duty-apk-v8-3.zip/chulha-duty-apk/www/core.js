(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.Core = api;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var CHEFS = ['Abdush Shakoor', 'Laique', 'Armoghan', 'Tousif', 'Kaif'];
  var N = CHEFS.length;
  var PAIRS = [[0, 1], [2, 3], [4, 0], [1, 2], [3, 4]];
  var DEFAULT_START = '2026-10-02';
  var MAX_SIM = 20000;

  /* ---------- dates (integer day numbers, no DST issues) ---------- */
  function dayNum(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(typeof s === 'string' ? s : '');
    if (!m) return null;
    var y = +m[1], mo = +m[2], d = +m[3];
    var t = Date.UTC(y, mo - 1, d), x = new Date(t);
    if (x.getUTCFullYear() !== y || x.getUTCMonth() !== mo - 1 || x.getUTCDate() !== d) return null;
    return Math.round(t / 86400000);
  }
  function isoOf(n) {
    var x = new Date(n * 86400000);
    return x.getUTCFullYear() + '-' + String(x.getUTCMonth() + 1).padStart(2, '0') + '-' + String(x.getUTCDate()).padStart(2, '0');
  }
  function validChef(i) {
    if (i === null || i === undefined || i === '' || typeof i === 'boolean') return false;
    var n = Number(i);
    return Number.isInteger(n) && n >= 0 && n < N;
  }
  function normalizeAmount(v) {
    var n = Number(v);
    return isFinite(n) ? Math.round(n * 100) / 100 : 0;
  }
  function toP(n) { return Math.round(Number(n || 0) * 100); }
  function newId() {
    return 'id-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
  }

  /* ---------- duty engine ----------
     Base rotation: 5 pairs repeat (1-2, 3-4, 5-1, 2-3, 4-5), so a chef cooks 4 days in 10.
     Off days (everyone) do not advance the rotation.
     If a chef in the pair is away, the next-numbered free chef covers. The absent chef then
     takes the cover's next slot (pending swap). */
  function createEngine(cfg) {
    var start = dayNum(cfg.startDate);
    if (start === null) start = dayNum(DEFAULT_START);
    var sp = (((cfg.startPair | 0) % N) + N) % N;
    var weekly = {};
    (cfg.weeklyOff || []).forEach(function (w) { weekly[w] = true; });
    var offs = (cfg.offDays || []).map(function (r) {
      return { from: dayNum(r.from), to: dayNum(r.to), reason: r.reason || '' };
    }).filter(function (r) { return r.from !== null && r.to !== null; });
    var aways = (cfg.aways || []).map(function (a) {
      return { chef: Number(a.chef), from: dayNum(a.from), to: a.to ? dayNum(a.to) : Infinity };
    }).filter(function (a) { return validChef(a.chef) && a.from !== null && a.to !== null; });

    function weekday(d) { return new Date(d * 86400000).getUTCDay(); }
    function manualOff(d) {
      for (var i = 0; i < offs.length; i++) {
        if (d >= offs[i].from && d <= offs[i].to) return { type: 'range', reason: offs[i].reason };
      }
      if (weekly[weekday(d)]) return { type: 'weekly', reason: 'Weekly off' };
      return null;
    }
    function awayOn(c, d) {
      for (var i = 0; i < aways.length; i++) {
        if (aways[i].chef === c && d >= aways[i].from && d <= aways[i].to) return aways[i];
      }
      return null;
    }
    function presentChefs(d) {
      var out = [];
      for (var c = 0; c < N; c++) if (!awayOn(c, d)) out.push(c);
      return out;
    }

    var cache = {}, snaps = {}, cursor = start - 1, ci = 0;
    var pending = [];
    for (var p = 0; p < N; p++) pending.push([]);

    function snap() { return pending.map(function (l) { return l.slice(); }); }

    function stepDay(d) {
      var off = manualOff(d);
      if (off) return { day: d, off: true, offType: off.type, reason: off.reason };
      var present = presentChefs(d);
      if (!present.length) return { day: d, off: true, offType: 'allAway', reason: 'Everyone is away' };

      var k = ci + sp;
      ci++;
      var base = PAIRS[((k % N) + N) % N];
      var slots = [
        { chef: base[0], note: null },
        { chef: base[1], note: null }
      ];
      function inPair(c) { return slots[0].chef === c || slots[1].chef === c; }
      function isPresent(c) { return present.indexOf(c) >= 0; }

      // 1) repay: a chef who owes a swap takes the cover's slot
      slots.forEach(function (s) {
        var list = pending[s.chef];
        for (var i = 0; i < list.length; i++) {
          var a = list[i];
          if (isPresent(a) && !inPair(a)) {
            list.splice(i, 1);
            s.note = { type: 'repay', other: s.chef };
            s.chef = a;
            break;
          }
        }
      });
      // 2) cover: absent chef is replaced by the next free number
      slots.forEach(function (s) {
        if (s.chef === null || isPresent(s.chef)) return;
        var abs = s.chef, found = -1;
        for (var j = 1; j < N; j++) {
          var c = (abs + j) % N;
          if (isPresent(c) && !inPair(c)) { found = c; break; }
        }
        if (found < 0) { s.note = { type: 'none', other: abs }; s.chef = null; return; }
        pending[found].push(abs);
        s.note = { type: 'cover', other: abs };
        s.chef = found;
      });

      return {
        day: d,
        off: false,
        label: (((k % 10) + 10) % 10) + 1,
        base: base.slice(),
        slots: slots.map(function (s) { return { chef: s.chef, note: s.note }; }),
        pair: slots.map(function (s) { return s.chef; }).filter(function (c) { return c !== null; })
      };
    }

    function ensure(d) {
      if (d > start + MAX_SIM) d = start + MAX_SIM;
      while (cursor < d) {
        cursor++;
        cache[cursor] = stepDay(cursor);
        snaps[cursor] = snap();
      }
    }

    function dutyFor(d) {
      if (d < start) {
        var off = manualOff(d);
        if (off) return { day: d, off: true, offType: off.type, reason: off.reason };
        var k = d - start + sp, b = PAIRS[(((k % N) + N) % N)];
        return {
          day: d, off: false, label: (((k % 10) + 10) % 10) + 1, base: b.slice(),
          slots: b.map(function (c) { return { chef: c, note: null }; }), pair: b.slice()
        };
      }
      ensure(d);
      return cache[d] || cache[cursor];
    }

    function debtsAt(d) {
      if (d < start) return [];
      ensure(d);
      var s = snaps[d] || snaps[cursor] || snap(), out = [];
      s.forEach(function (list, owner) {
        list.forEach(function (by) { out.push({ owner: owner, by: by }); });
      });
      return out;
    }

    return { dutyFor: dutyFor, debtsAt: debtsAt, presentChefs: presentChefs, awayOn: awayOn, manualOff: manualOff };
  }

  function slotLabel(s) {
    if (s.chef === null) return null;
    var t = CHEFS[s.chef];
    if (s.note && s.note.type === 'cover') t += ' (covering ' + CHEFS[s.note.other] + ')';
    else if (s.note && s.note.type === 'repay') t += ' (paying back ' + CHEFS[s.note.other] + ')';
    return t;
  }
  function dutyText(res) {
    if (!res || res.off) return 'No cooking';
    return res.slots.map(slotLabel).filter(Boolean).join(' + ') || 'Nobody is free';
  }

  /* ---------- accounting (integer paise, equal split among participants) ---------- */
  function participantsOf(e) {
    var list = Array.isArray(e.participants) ? e.participants.filter(validChef).map(Number) : [];
    list = list.filter(function (c, i) { return list.indexOf(c) === i; }).sort(function (a, b) { return a - b; });
    if (!list.length) for (var i = 0; i < N; i++) list.push(i);
    return list;
  }
  function expenseTotalP(e) {
    var t = 0;
    (e.payments || []).forEach(function (p) {
      if (!validChef(p.chef)) return;
      (p.items || []).forEach(function (x) { t += toP(x.amount); });
    });
    return t;
  }
  function balancesFor(expenses, settlements) {
    var paid = [], share = [], i;
    for (i = 0; i < N; i++) { paid.push(0); share.push(0); }
    expenses.forEach(function (e) {
      (e.payments || []).forEach(function (p) {
        if (!validChef(p.chef)) return;
        var amt = 0;
        (p.items || []).forEach(function (x) { amt += toP(x.amount); });
        paid[Number(p.chef)] += amt;
      });
      var total = expenseTotalP(e), parts = participantsOf(e), n = parts.length;
      var base = Math.floor(total / n), rem = total - base * n;
      var dn = dayNum(e.date), start = ((dn === null ? 0 : dn) % n + n) % n;
      for (var k = 0; k < n; k++) share[parts[(start + k) % n]] += base + (k < rem ? 1 : 0);
    });
    var bal = paid.map(function (p, j) { return p - share[j]; });
    (settlements || []).forEach(function (s) {
      var amt = toP(s.amount);
      if (amt <= 0 || !validChef(s.from) || !validChef(s.to) || Number(s.from) === Number(s.to)) return;
      bal[Number(s.from)] += amt;
      bal[Number(s.to)] -= amt;
    });
    return CHEFS.map(function (name, j) {
      return { name: name, paid: paid[j] / 100, share: share[j] / 100, balance: bal[j] / 100, balanceP: bal[j] };
    });
  }
  function makeSuggestions(bal) {
    var debtors = [], creditors = [];
    bal.forEach(function (b, i) {
      if (b.balanceP < 0) debtors.push({ chef: i, left: -b.balanceP });
      else if (b.balanceP > 0) creditors.push({ chef: i, left: b.balanceP });
    });
    debtors.sort(function (a, b) { return b.left - a.left; });
    creditors.sort(function (a, b) { return b.left - a.left; });
    var out = [], d = 0, c = 0;
    while (d < debtors.length && c < creditors.length) {
      var amt = Math.min(debtors[d].left, creditors[c].left);
      out.push({ from: debtors[d].chef, to: creditors[c].chef, amount: amt / 100 });
      debtors[d].left -= amt;
      creditors[c].left -= amt;
      if (!debtors[d].left) d++;
      if (!creditors[c].left) c++;
    }
    return out;
  }

  /* ---------- state ---------- */
  function defaultState() {
    return {
      version: 5, startDate: DEFAULT_START, startPair: 0, theme: 'system', perf: 'auto',
      notify: { on: false, time: '17:00' }, weeklyOff: [], offDays: [], aways: [],
      expenses: [], settlements: [], lastBackup: null
    };
  }
  function migrateAll(list, fn) {
    var seen = {}, out = [], skipped = 0;
    list.forEach(function (x) {
      var r = fn(x, seen);
      if (r) out.push(r); else skipped++;
    });
    return { out: out, skipped: skipped };
  }
  function uniqueId(id, seen) {
    var v = typeof id === 'string' && id && !seen[id] ? id : newId();
    while (seen[v]) v = newId();
    seen[v] = true;
    return v;
  }
  function migrateItems(items, fallbackAmount, fallbackLabel) {
    var src = Array.isArray(items) ? items : [{ label: fallbackLabel, amount: fallbackAmount }];
    return src.map(function (x) {
      x = x || {};
      var label = String(x.label || 'Kitchen item').trim().slice(0, 80) || 'Kitchen item';
      return { label: label, amount: normalizeAmount(x.amount) };
    }).filter(function (x) { return x.amount > 0; });
  }
  function migrateExpense(e, seen) {
    if (!e || typeof e !== 'object' || dayNum(e.date) === null) return null;
    var payments;
    if (Array.isArray(e.payments)) {
      payments = e.payments.map(function (p) {
        if (!p || !validChef(p.chef)) return null;
        var items = migrateItems(p.items, p.amount, e.note || 'Kitchen expense');
        return items.length ? { chef: Number(p.chef), items: items } : null;
      }).filter(Boolean);
    } else {
      var chef = [e.payer, e.chef, e.paidBy].filter(validChef)[0];
      var items2 = chef === undefined ? [] : migrateItems(null, e.amount, e.note || 'Kitchen expense');
      payments = items2.length ? [{ chef: Number(chef), items: items2 }] : [];
    }
    if (!payments.length) return null;
    var amount = 0;
    payments.forEach(function (p) { p.items.forEach(function (x) { amount += toP(x.amount); }); });
    return {
      id: uniqueId(e.id, seen), date: e.date, amount: amount / 100, payments: payments,
      participants: participantsOf(e),
      createdAt: typeof e.createdAt === 'string' ? e.createdAt : new Date().toISOString()
    };
  }
  function migrateSettlement(s, seen) {
    if (!s || typeof s !== 'object' || dayNum(s.date) === null || !validChef(s.from) || !validChef(s.to) ||
      Number(s.from) === Number(s.to) || normalizeAmount(s.amount) <= 0) return null;
    return {
      id: uniqueId(s.id, seen), date: s.date, scope: s.scope === 'all' ? 'all' : 'day',
      from: Number(s.from), to: Number(s.to), amount: normalizeAmount(s.amount)
    };
  }
  function migrateOff(r, seen) {
    if (!r || typeof r !== 'object') return null;
    var a = dayNum(r.from), b = dayNum(r.to || r.from);
    if (a === null || b === null) return null;
    if (a > b) { var t = a; a = b; b = t; }
    return { id: uniqueId(r.id, seen), from: isoOf(a), to: isoOf(b), reason: String(r.reason || '').trim().slice(0, 60) };
  }
  function migrateAway(r, seen) {
    if (!r || typeof r !== 'object' || !validChef(r.chef)) return null;
    var a = dayNum(r.from);
    if (a === null) return null;
    var b = r.to ? dayNum(r.to) : null;
    if (r.to && b === null) return null;
    if (b !== null && a > b) { var t = a; a = b; b = t; }
    return {
      id: uniqueId(r.id, seen), chef: Number(r.chef), from: isoOf(a), to: b === null ? null : isoOf(b),
      note: String(r.note || '').trim().slice(0, 60)
    };
  }
  function sanitizeState(raw) {
    var base = defaultState();
    raw = raw && typeof raw === 'object' ? raw : {};
    var ex = migrateAll(Array.isArray(raw.expenses) ? raw.expenses : [], migrateExpense);
    var st = migrateAll(Array.isArray(raw.settlements) ? raw.settlements : [], migrateSettlement);
    var of = migrateAll(Array.isArray(raw.offDays) ? raw.offDays : [], migrateOff);
    var aw = migrateAll(Array.isArray(raw.aways) ? raw.aways : [], migrateAway);
    var pair = Number(raw.startPair);
    var wk = (Array.isArray(raw.weeklyOff) ? raw.weeklyOff : []).map(Number).filter(function (w, i, a) {
      return Number.isInteger(w) && w >= 0 && w <= 6 && a.indexOf(w) === i;
    });
    var nt = raw.notify && typeof raw.notify === 'object' ? raw.notify : {};
    var tm = /^([01]\d|2[0-3]):[0-5]\d$/.test(nt.time) ? nt.time : base.notify.time;
    return {
      state: {
        version: 5,
        startDate: dayNum(raw.startDate) !== null ? raw.startDate : base.startDate,
        startPair: Number.isInteger(pair) && pair >= 0 && pair < PAIRS.length ? pair : 0,
        theme: ['light', 'dark', 'system'].indexOf(raw.theme) >= 0 ? raw.theme : 'system',
        perf: ['auto', 'on', 'off'].indexOf(raw.perf) >= 0 ? raw.perf : 'auto',
        notify: { on: !!nt.on, time: tm },
        weeklyOff: wk, offDays: of.out, aways: aw.out,
        expenses: ex.out, settlements: st.out,
        lastBackup: dayNum(raw.lastBackup) !== null ? raw.lastBackup : null
      },
      skipped: ex.skipped + st.skipped + of.skipped + aw.skipped
    };
  }
  var PHOTO_RE = /^data:image\/jpeg;base64,[A-Za-z0-9+\/=]+$/;
  function sanitizePhotos(raw) {
    var out = {};
    if (!raw || typeof raw !== 'object') return out;
    for (var i = 0; i < N; i++) {
      var v = raw[i];
      if (typeof v === 'string' && v.length < 250000 && PHOTO_RE.test(v)) out[i] = v;
    }
    return out;
  }

  return {
    CHEFS: CHEFS, N: N, PAIRS: PAIRS, DEFAULT_START: DEFAULT_START,
    dayNum: dayNum, isoOf: isoOf, validChef: validChef, normalizeAmount: normalizeAmount, toP: toP, newId: newId,
    createEngine: createEngine, dutyText: dutyText, slotLabel: slotLabel,
    participantsOf: participantsOf, expenseTotalP: expenseTotalP, balancesFor: balancesFor, makeSuggestions: makeSuggestions,
    defaultState: defaultState, sanitizeState: sanitizeState, sanitizePhotos: sanitizePhotos
  };
});
