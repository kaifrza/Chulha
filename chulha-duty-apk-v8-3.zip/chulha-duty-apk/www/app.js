(function () {
'use strict';

const C = window.Core, CHEFS = C.CHEFS, N = C.N;
const $ = (s) => document.querySelector(s);
const $$ = (s) => Array.prototype.slice.call(document.querySelectorAll(s));
const money = (n) => {
  n = Number(n || 0);
  const frac = Math.abs(Math.round(n * 100) % 100) !== 0;
  return (n < 0 ? '\u2212' : '') + '\u20B9' + Math.abs(n).toLocaleString('en-IN', { minimumFractionDigits: frac ? 2 : 0, maximumFractionDigits: 2 });
};
const ico = (n, c) => '<svg class="ico ' + (c || '') + '" aria-hidden="true"><use href="#i-' + n + '"/></svg>';
const toP = C.toP;
const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

let state = C.defaultState();
let photos = {};
let engine = null, expIdx = null;
let selectedDate = localNoon(new Date());
let todayIso = iso(new Date());
let activePage = 'home';
let dirty = {};
let ledgerMode = 'day';
let toastTimer = null, notifTimer = null;
let expenseEditId = null, partSel = [], partTouched = false;
let rangeKind = 'off';
let photoTarget = null;
let sheetBusy = false;

/* ---------- helpers ---------- */
function localNoon(d) { const x = new Date(d); x.setHours(12, 0, 0, 0); return x; }
function iso(d) { return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function parseDate(s) {
  const n = C.dayNum(s);
  if (n === null) return null;
  const p = s.split('-');
  return new Date(+p[0], +p[1] - 1, +p[2], 12);
}
function dn(d) { return C.dayNum(iso(d)); }
function diffDays(a, b) { return dn(a) - dn(b); }
function fmt(d, opts) { return d.toLocaleDateString(undefined, opts || { weekday: 'short', month: 'short', day: 'numeric' }); }
function relLabel(d) {
  const n = diffDays(d, new Date());
  return n === 0 ? 'Today' : n === 1 ? 'Tomorrow' : n === -1 ? 'Yesterday' : fmt(d, { weekday: 'long' });
}
function shortDate(s) { const d = parseDate(s); return d ? fmt(d, { month: 'short', day: 'numeric' }) : s; }
function initials(n) { return n.split(' ').map((x) => x[0]).slice(0, 2).join('').toUpperCase(); }
function esc(s) { return String(s).replace(/[&<>'"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[c])); }
function avatarInner(i) { return photos[i] ? '<img src="' + photos[i] + '" alt="" decoding="async">' : esc(initials(CHEFS[i])); }
function plural(n, a, b) { return n === 1 ? a : b; }

/* ---------- engine, indexes ---------- */
function eng() { if (!engine) engine = C.createEngine(state); return engine; }
function dutyAt(date) { return eng().dutyFor(dn(date)); }
function expIndex() {
  if (!expIdx) {
    expIdx = {};
    state.expenses.forEach((e) => { (expIdx[e.date] || (expIdx[e.date] = [])).push(e); });
  }
  return expIdx;
}
function expensesForDate(date) { return expIndex()[iso(date)] || []; }
function settlementsForDate(date) { const k = iso(date); return state.settlements.filter((s) => s.date === k && s.scope !== 'all'); }
function dateTotal(date) { return expensesForDate(date).reduce((s, e) => s + C.expenseTotalP(e), 0) / 100; }
function totalExpenses() { return state.expenses.reduce((s, e) => s + C.expenseTotalP(e), 0) / 100; }
function allBalances() { return C.balancesFor(state.expenses, state.settlements); }
function dailyBalances(date) { return C.balancesFor(expensesForDate(date), settlementsForDate(date)); }
function balanceStatus(p) {
  if (p > 0) return { cls: 'positive', label: 'Gets back' };
  if (p < 0) return { cls: 'negative', label: 'Owes' };
  return { cls: 'neutral', label: 'Settled' };
}
function firstName(i) { return CHEFS[i].split(' ')[0]; }
function pairNames(res) {
  return res.slots.filter((s) => s.chef !== null).map((s) => CHEFS[s.chef]).join(' + ') || 'Nobody is free';
}
function pairNotes(res) {
  return res.slots.filter((s) => s.note && s.note.type !== 'none' && s.chef !== null).map((s) =>
    firstName(s.chef) + (s.note.type === 'cover' ? ' covers ' : ' pays back ') + firstName(s.note.other)).join(' \u00B7 ');
}
function noteText(n) {
  if (!n) return '';
  if (n.type === 'cover') return 'Covering for ' + CHEFS[n.other];
  if (n.type === 'repay') return 'Paying back ' + CHEFS[n.other];
  return '';
}

/* ---------- state changes ---------- */
function commit(kind) {
  expIdx = null;
  if (kind === 'duty') { engine = null; scheduleNotify(); }
  Store.save(state);
  refresh();
}
function persist() { Store.save(state); }

/* ---------- render: home ---------- */
function renderHome() {
  const d = selectedDate, res = dutyAt(d), list = expensesForDate(d), total = dateTotal(d);
  const n = diffDays(d, new Date()), isToday = n === 0;
  $('#homeRel').textContent = relLabel(d);
  $('#homeDateTitle').textContent = fmt(d, { weekday: 'long', month: 'short', day: 'numeric' });
  $('#todayLabel').textContent = fmt(d, { weekday: 'long', month: 'long', day: 'numeric' });

  const away = [];
  for (let c = 0; c < N; c++) if (eng().awayOn(c, dn(d))) away.push(CHEFS[c].split(' ')[0]);
  const rel = isToday ? 'Today' : n === 1 ? 'Tomorrow' : n === -1 ? 'Yesterday' : fmt(d, { year: 'numeric' });
  $('#dateStatus').textContent = (res.off ? 'Off day' : 'Cooking day') + ' \u00B7 ' + rel + (away.length ? ' \u00B7 ' + away.join(', ') + ' away' : '');

  if (res.off) {
    $('#dutyLabel').textContent = 'No cooking';
    $('#dayNumber').textContent = 'Off day';
    $('#dutyCards').innerHTML = '<div class="off-state"><div class="off-ico">' + ico('pause') + '</div><b>Nobody cooks ' + (isToday ? 'today' : 'this day') + '</b><small>' + esc(res.reason || 'Off day') + '</small></div>';
  } else {
    $('#dutyLabel').textContent = isToday ? 'On duty today' : 'On duty this day';
    $('#dayNumber').textContent = 'Day ' + res.label + ' of 10';
    $('#dutyCards').innerHTML = res.slots.map((s, k) => {
      if (s.chef === null) return '<div class="burner empty"><div class="burner-ring"><div class="burner-core">?</div></div><div><div class="chef-name">Nobody free</div><div class="chef-num">Chulha ' + (k + 1) + '</div></div></div>';
      const note = noteText(s.note);
      return '<div class="burner"><div class="burner-ring"><div class="burner-core">' + avatarInner(s.chef) + '</div></div><div><div class="chef-name">' + esc(CHEFS[s.chef]) + '</div><div class="chef-num">Chulha ' + (k + 1) + '</div>' + (note ? '<div class="chef-note">' + esc(note) + '</div>' : '') + '</div></div>';
    }).join('');
  }

  $('#dayExpenseTotal').textContent = money(total);
  $('#expenseCount').textContent = list.length ? list.length + ' expense ' + plural(list.length, 'entry', 'entries') : 'No entries yet';
  const payers = {};
  list.forEach((e) => e.payments.forEach((p) => { payers[p.chef] = 1; }));
  const pc = Object.keys(payers).length;
  $('#dayExpensePayerHint').textContent = list.length ? pc + ' ' + plural(pc, 'payer', 'payers') : '';
  $('#dayExpenses').innerHTML = list.length ? list.map(expenseCard).join('') : emptyExpense();

  const rows = [];
  for (let k = 1; k <= 4; k++) {
    const nd = new Date(d); nd.setDate(nd.getDate() + k);
    const r = dutyAt(nd);
    rows.push('<div class="duty-row' + (r.off ? ' is-off' : '') + '"><div class="date"><b>' + (k === 1 ? 'Tomorrow' : fmt(nd, { weekday: 'short' })) + '</b><small>' + fmt(nd, { month: 'short', day: 'numeric' }) + '</small></div><div class="pair">' + (r.off ? 'Off day<span>' + esc(r.reason || '') + '</span>' : esc(pairNames(r)) + '<span>' + esc(pairNotes(r) || 'Chulha 1 + Chulha 2') + '</span>') + '</div></div>');
  }
  $('#upcoming').innerHTML = rows.join('');

  const nudge = $('#backupNudge');
  const since = state.lastBackup ? todayDiff(state.lastBackup) : null;
  const show = state.expenses.length > 0 && (since === null || since >= 7);
  nudge.hidden = !show;
  if (show) $('#nudgeText').textContent = since === null ? 'You have not backed up yet.' : 'Last backup was ' + since + ' days ago.';
}
function todayDiff(isoStr) { const n = C.dayNum(isoStr); return n === null ? null : dn(new Date()) - n; }

function emptyExpense() {
  return '<div class="empty-state"><div class="empty-icon">' + ico('receipt') + '</div><b>No expense for this day</b><small>Record the day\'s purchases before the cooking day ends.</small><button class="primary add-expense-btn" type="button">' + ico('plus', 'sm') + 'Add first expense</button></div>';
}
function expenseCard(e) {
  const lines = e.payments.map((p) => {
    const items = p.items.map((x) => esc(x.label) + ' ' + money(x.amount)).join(', ');
    const sub = p.items.reduce((s, x) => s + toP(x.amount), 0) / 100;
    return '<div class="payer-line"><strong>' + esc(CHEFS[p.chef] || 'Unknown') + '</strong> paid ' + money(sub) + ' \u00B7 ' + items + '</div>';
  }).join('');
  const parts = C.participantsOf(e);
  const eaters = parts.length < N ? '<div class="payer-line">Shared by ' + parts.length + ': ' + parts.map((i) => esc(CHEFS[i].split(' ')[0])).join(', ') + '</div>' : '';
  return '<div class="expense-row"><div class="expense-main"><div class="expense-icon">' + ico('receipt') + '</div><div class="expense-text"><b>' + money(C.expenseTotalP(e) / 100) + '</b>' + lines + eaters + '</div></div><div class="row-actions"><button class="icon-btn small edit-expense" type="button" data-id="' + esc(e.id) + '" aria-label="Edit expense">' + ico('edit', 'sm') + '</button><button class="icon-btn small danger-text delete-expense" type="button" data-id="' + esc(e.id) + '" aria-label="Delete expense">' + ico('trash', 'sm') + '</button></div></div>';
}

/* ---------- render: schedule ---------- */
function renderSchedule() {
  const y = selectedDate.getFullYear(), m = selectedDate.getMonth();
  $('#scheduleMonth').textContent = new Date(y, m, 1, 12).toLocaleDateString(undefined, { month: 'long', year: 'numeric' });
  renderRanges();
  const days = new Date(y, m + 1, 0).getDate(), tI = iso(new Date()), sI = iso(selectedDate), rows = [];
  for (let k = 1; k <= days; k++) {
    const d = new Date(y, m, k, 12), r = dutyAt(d), total = dateTotal(d), key = iso(d);
    const swap = !r.off && r.slots.some((s) => s.note);
    const right = r.off
      ? 'Off day<span>' + esc(r.reason || '') + '</span>'
      : esc(pairNames(r)) + '<span>' + (pairNotes(r) ? esc(pairNotes(r)) + ' \u00B7 ' : '') + (total ? money(total) + ' spent \u00B7 ' : '') + 'Day ' + r.label + '</span>';
    rows.push('<button type="button" class="duty-row as-btn' + (key === sI ? ' selected' : '') + (r.off ? ' is-off' : '') + '" data-date="' + key + '"><div class="date"><b>' + fmt(d, { weekday: 'short', day: 'numeric' }) + (key === tI ? '<span class="tag">Today</span>' : '') + (swap ? '<span class="tag">Swap</span>' : '') + '</b><small>' + fmt(d, { month: 'short', year: 'numeric' }) + '</small></div><div class="pair">' + right + '</div></button>');
  }
  $('#scheduleList').innerHTML = rows.join('');
}
function renderRanges() {
  const t = iso(new Date());
  const items = [];
  state.offDays.forEach((r) => items.push({ kind: 'off', r: r }));
  state.aways.forEach((r) => items.push({ kind: 'away', r: r }));
  items.sort((a, b) => (a.r.from < b.r.from ? 1 : -1));
  const html = items.slice(0, 20).map((it) => {
    const r = it.r, past = r.to !== null && r.to < t;
    const range = r.to === null ? shortDate(r.from) + ' \u2013 ongoing' : (r.from === r.to ? shortDate(r.from) : shortDate(r.from) + ' \u2013 ' + shortDate(r.to));
    const active = it.kind === 'away' && r.from <= t && (r.to === null || r.to >= t);
    const title = it.kind === 'off' ? 'Off day' : CHEFS[r.chef] + ' away';
    const note = it.kind === 'off' ? r.reason : r.note;
    return '<div class="range-row' + (past ? ' past' : '') + '"><div class="range-ico">' + ico(it.kind === 'off' ? 'pause' : 'door') + '</div><div class="range-main"><b>' + esc(title) + '</b><small>' + esc(range) + (note ? ' \u00B7 ' + esc(note) : '') + '</small></div>' + (active ? '<button class="ghost back-away" type="button" data-id="' + esc(r.id) + '">Back</button>' : '') + '<button class="icon-btn small delete-range" type="button" data-kind="' + it.kind + '" data-id="' + esc(r.id) + '" aria-label="Delete">' + ico('trash', 'sm') + '</button></div>';
  }).join('');
  $('#rangeList').innerHTML = html || '<div class="empty-state compact"><small>No off days or away records.</small></div>';
}

/* ---------- render: chefs ---------- */
function awayId(chef, d) {
  const t = C.isoOf(d), m = state.aways.filter((x) => x.chef === chef && x.from <= t && (x.to === null || x.to >= t))[0];
  return m ? m.id : '';
}
function renderChefs() {
  const bal = allBalances(), td = dn(new Date()), res = eng().dutyFor(td), debts = eng().debtsAt(td);
  $('#chefList').innerHTML = CHEFS.map((n, i) => {
    const b = bal[i], st = balanceStatus(b.balanceP), tags = [];
    if (!res.off && res.pair.indexOf(i) >= 0) tags.push('<span class="tagx warn">On duty today</span>');
    const aw = eng().awayOn(i, td);
    if (aw) tags.push('<span class="tagx warn">Away' + (aw.to === Infinity ? ' \u00B7 until marked back' : ' \u00B7 back ' + shortDate(C.isoOf(aw.to + 1))) + '</span>');
    debts.forEach((d) => {
      if (d.by === i) tags.push('<span class="tagx">Takes ' + esc(CHEFS[d.owner].split(' ')[0]) + '\'s next turn</span>');
      if (d.owner === i) tags.push('<span class="tagx">' + esc(CHEFS[d.by].split(' ')[0]) + ' will take your next turn</span>');
    });
    return '<div class="profile"><div class="profile-top"><button class="photo-btn" type="button" data-chef="' + i + '" aria-label="Change photo of ' + esc(n) + '"><span class="avatar">' + avatarInner(i) + '</span><span class="photo-badge">' + ico('camera') + '</span></button><div class="profile-info"><b>' + esc(n) + '</b><small>Chef ' + (i + 1) + '</small></div><div class="stat ' + st.cls + '"><b>' + (b.balanceP > 0 ? '+' : '') + money(b.balance) + '</b><small>all-time balance</small></div></div>' + (tags.length ? '<div class="tag-row">' + tags.join('') + '</div>' : '') + '<div class="profile-actions">' + (aw ? '<button class="ghost back-away" type="button" data-id="' + esc(awayId(i, td)) + '">' + ico('check', 'sm') + 'Back today</button>' : '') + '<button class="ghost add-away" type="button" data-chef="' + i + '">' + ico('door', 'sm') + (aw ? 'Another leave' : 'Mark away') + '</button>' + (photos[i] ? '<button class="ghost danger-text rm-photo" type="button" data-chef="' + i + '">Remove photo</button>' : '') + '</div></div>';
  }).join('');
}

/* ---------- render: hisaab ---------- */
function renderBalanceList(el, bal) {
  el.innerHTML = bal.map((b, i) => {
    const st = balanceStatus(b.balanceP);
    return '<div class="balance-row"><span class="avatar mini">' + avatarInner(i) + '</span><div class="balance-person"><b>' + esc(b.name) + '</b><small>Share ' + money(b.share) + ' \u00B7 Paid ' + money(b.paid) + '</small></div><div class="balance-value ' + st.cls + '"><b>' + (b.balanceP > 0 ? '+' : '') + money(b.balance) + '</b><small>' + st.label + '</small></div></div>';
  }).join('');
}
function renderSettlementList(el, list) {
  el.innerHTML = list.length
    ? list.map((s, i) => '<div class="settle-row"><div class="settle-flow"><span class="settle-index">' + (i + 1) + '</span><div><b>' + esc(CHEFS[s.from]) + '</b><span>pays</span><b>' + esc(CHEFS[s.to]) + '</b></div></div><strong>' + money(s.amount) + '</strong><button class="ghost record-settle" type="button" data-from="' + s.from + '" data-to="' + s.to + '" data-amount="' + s.amount + '">' + ico('check', 'sm') + 'Mark as paid</button></div>').join('')
    : '<div class="empty-state compact ok"><div class="empty-icon">' + ico('check') + '</div><b>Everyone is settled</b><small>No outstanding transfer is needed.</small></div>';
}
function renderSettlementHistory(el, items, showScope) {
  el.innerHTML = items.length
    ? items.slice().reverse().map((s) => '<div class="settle-history"><div><b>' + esc(CHEFS[s.from]) + ' to ' + esc(CHEFS[s.to]) + '</b><small>' + fmt(parseDate(s.date) || new Date(), { month: 'short', day: 'numeric', year: 'numeric' }) + (showScope ? ' \u00B7 ' + (s.scope === 'all' ? 'All-time' : 'Day account') : '') + '</small></div><strong>' + money(s.amount) + '</strong><button class="ghost danger-text delete-settle" type="button" data-id="' + esc(s.id) + '" aria-label="Undo this transfer">' + ico('undo', 'sm') + 'Undo</button></div>').join('')
    : '<div class="empty-state compact"><small>No transfers recorded yet.</small></div>';
}
function renderDayLedger() {
  const d = selectedDate, expenses = expensesForDate(d), bal = dailyBalances(d), sug = C.makeSuggestions(bal), total = dateTotal(d), res = dutyAt(d);
  $('#ledgerDate').textContent = fmt(d, { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' });
  $('#ledgerDuty').textContent = res.off ? 'Off day' : pairNames(res);
  $('#ledgerDayExpenseHint').textContent = expenses.length ? expenses.length + ' expense ' + plural(expenses.length, 'entry', 'entries') : 'No expense yet';
  $('#ledgerExpenseLabel').textContent = diffDays(d, new Date()) === 0 ? 'Kitchen spend today' : 'Kitchen spend this day';
  $('#totalSpend').textContent = money(total);
  $('#expenseDays').textContent = expenses.length ? expenses.length + ' recorded purchase ' + plural(expenses.length, 'entry', 'entries') : 'Add the first purchase for this day';
  renderBalanceList($('#balanceList'), bal);
  const out = sug.reduce((s, x) => s + toP(x.amount), 0) / 100;
  $('#settlementMeta').textContent = sug.length ? sug.length + ' ' + plural(sug.length, 'transfer', 'transfers') + ' \u00B7 ' + money(out) + ' outstanding' : 'All balances settled';
  renderSettlementList($('#settlementList'), sug);
  renderSettlementHistory($('#settlementHistory'), settlementsForDate(d), false);
}
function renderAllLedger() {
  const bal = allBalances(), sug = C.makeSuggestions(bal), days = {};
  state.expenses.forEach((e) => { days[e.date] = 1; });
  const dc = Object.keys(days).length;
  $('#allTotalSpend').textContent = money(totalExpenses());
  $('#allExpenseDays').textContent = dc + ' cooking ' + plural(dc, 'day', 'days');
  renderBalanceList($('#allBalanceList'), bal);
  const out = sug.reduce((s, x) => s + toP(x.amount), 0) / 100;
  $('#allSettlementMeta').textContent = sug.length ? sug.length + ' ' + plural(sug.length, 'transfer', 'transfers') + ' \u00B7 ' + money(out) + ' outstanding' : 'All balances settled';
  renderSettlementList($('#allSettlementList'), sug);
  renderSettlementHistory($('#allSettlementHistory'), state.settlements, true);
}
function renderHisaab() {
  const day = ledgerMode === 'day';
  $('#dayLedgerView').hidden = !day;
  $('#allLedgerView').hidden = day;
  $('#dayLedgerBtn').classList.toggle('active', day);
  $('#allLedgerBtn').classList.toggle('active', !day);
  $('#dayLedgerBtn').setAttribute('aria-selected', String(day));
  $('#allLedgerBtn').setAttribute('aria-selected', String(!day));
  $('.segmented').dataset.mode = day ? 'day' : 'all';
  $('.ledger-date-card').hidden = !day;
  if (day) renderDayLedger(); else renderAllLedger();
}

/* ---------- render: settings ---------- */
function lowEnd() {
  const cores = navigator.hardwareConcurrency || 8, mem = navigator.deviceMemory || 4;
  return cores <= 4 || mem <= 3;
}
function liteOn() { return state.perf === 'on' || (state.perf === 'auto' && lowEnd()); }
function renderSettings() {
  $('#startDate').value = state.startDate;
  $('#startPair').innerHTML = C.PAIRS.map((p, i) => '<option value="' + i + '">' + esc(CHEFS[p[0]]) + ' + ' + esc(CHEFS[p[1]]) + '</option>').join('');
  $('#startPair').value = state.startPair;
  $('#weekdayChips').innerHTML = WEEKDAYS.map((w, i) => '<button type="button" class="chip day' + (state.weeklyOff.indexOf(i) >= 0 ? ' on' : '') + '" data-day="' + i + '" aria-pressed="' + (state.weeklyOff.indexOf(i) >= 0) + '">' + w + '</button>').join('');
  $('#notifTime').value = state.notify.time;
  $('#notifToggle').checked = !!state.notify.on;
  if (!Native.isNative || !Native.notifSupported()) {
    $('#notifToggle').disabled = true;
    $('#notifTime').disabled = true;
    setNotifStatus('app');
  } else if (!$('#notifStatus').dataset.state) setNotifStatus(state.notify.on ? 'on' : 'off');
  $$('#perfOptions button').forEach((b) => { const on = b.dataset.perf === state.perf; b.classList.toggle('active', on); b.setAttribute('aria-pressed', String(on)); });
  $('#perfNote').textContent = 'Lite mode removes blur and heavy effects so the app stays smooth on low-end phones.' + (state.perf === 'auto' ? ' Auto is currently ' + (liteOn() ? 'Lite' : 'Full') + '.' : '');
  const since = state.lastBackup ? todayDiff(state.lastBackup) : null;
  $('#lastBackupText').textContent = 'Everything is saved on this phone only. ' + (since === null ? 'No backup yet.' : since === 0 ? 'Last backup: today.' : 'Last backup: ' + since + ' ' + plural(since, 'day', 'days') + ' ago.') + ' Back up now and then, so a lost or reset phone does not lose the hisaab.';
}
function setNotifStatus(kind) {
  const el = $('#notifStatus');
  el.dataset.state = kind;
  el.textContent = kind === 'app' ? 'Reminders work in the Android app.'
    : kind === 'denied' ? 'Notifications are blocked. Allow them in Android settings for this app.'
    : kind === 'on' ? 'You get a reminder on every cooking day.'
    : 'Get a notification on every cooking day.';
}
function applyTheme() {
  const dark = state.theme === 'dark' || (state.theme === 'system' && window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
  const meta = document.querySelector('meta[name=theme-color]');
  if (meta) meta.content = dark ? '#0b1412' : '#edf3f1';
  Native.setStatusBar(dark, dark ? '#0b1412' : '#edf3f1');
  $$('.theme-options button[data-theme-choice]').forEach((b) => { const on = b.dataset.themeChoice === state.theme; b.classList.toggle('active', on); b.setAttribute('aria-pressed', String(on)); });
}
function isDark() { return document.documentElement.getAttribute('data-theme') === 'dark'; }
function applyPerf() { document.documentElement.classList.toggle('lite', liteOn()); }

const RENDER = { home: renderHome, schedule: renderSchedule, chefs: renderChefs, hisaab: renderHisaab, settings: renderSettings };
function refresh() { dirty = { home: 1, schedule: 1, chefs: 1, hisaab: 1, settings: 1 }; renderActive(); }
function renderActive() { if (dirty[activePage]) { delete dirty[activePage]; RENDER[activePage](); } }

/* ---------- toast ---------- */
function hideToast() { clearTimeout(toastTimer); $('#toast').classList.remove('show'); }
function toast(msg, opts) {
  opts = opts || {};
  const el = $('#toast');
  clearTimeout(toastTimer);
  el.textContent = '';
  const s = document.createElement('span');
  s.textContent = msg;
  el.appendChild(s);
  el.classList.toggle('has-action', !!opts.action);
  if (opts.action) {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'toast-action'; b.textContent = opts.action;
    b.onclick = () => { hideToast(); if (opts.onAction) opts.onAction(); };
    el.appendChild(b);
  }
  el.classList.add('show');
  toastTimer = setTimeout(hideToast, opts.action ? 6000 : 3200);
}

/* ---------- navigation ---------- */
function openPage(p) {
  activePage = p;
  if (p === 'hisaab') dirty.hisaab = 1;
  $$('.page').forEach((x) => x.classList.toggle('active', x.id === p));
  $$('.nav').forEach((x) => { const on = x.dataset.page === p; x.classList.toggle('active', on); if (on) x.setAttribute('aria-current', 'page'); else x.removeAttribute('aria-current'); });
  renderActive();
  window.scrollTo(0, 0);
  if (p === 'schedule') requestAnimationFrame(() => { const el = $('.duty-row.selected'); if (el && el.scrollIntoView) el.scrollIntoView({ block: 'center' }); });
}
function shiftDate(delta) { selectedDate = localNoon(selectedDate); selectedDate.setDate(selectedDate.getDate() + delta); refresh(); }
function shiftMonth(delta) {
  const y = selectedDate.getFullYear(), m = selectedDate.getMonth() + delta, last = new Date(y, m + 1, 0).getDate();
  selectedDate = new Date(y, m, Math.min(selectedDate.getDate(), last), 12);
  refresh();
}
function setToday() { selectedDate = localNoon(new Date()); refresh(); }

/* ---------- sheets ---------- */
function openSheet(m) {
  m.classList.remove('closing');
  if (typeof m.showModal === 'function') { if (!m.open) m.showModal(); } else m.setAttribute('open', '');
}
function closeSheet(m, after) {
  if (!m.open || sheetBusy) return;
  sheetBusy = true;
  m.classList.add('closing');
  setTimeout(() => {
    if (typeof m.close === 'function') m.close(); else m.removeAttribute('open');
    m.classList.remove('closing');
    sheetBusy = false;
    if (after) after();
  }, liteOn() ? 60 : 190);
}
function closeTopSheet() {
  const a = $('#expenseModal'), b = $('#rangeModal');
  if (a.open) { closeSheet(a, () => { expenseEditId = null; }); return true; }
  if (b.open) { closeSheet(b); return true; }
  return false;
}
function backdropClose(m, fn) {
  let down = false;
  m.addEventListener('pointerdown', (e) => { down = e.target === m; });
  m.addEventListener('click', (e) => { if (down && e.target === m) fn(); down = false; });
  m.addEventListener('cancel', (e) => { e.preventDefault(); fn(); });
}

/* ---------- expense sheet ---------- */
function showExpenseError(msg) { const e = $('#expenseError'); e.textContent = msg; e.hidden = false; }
function hideExpenseError() { const e = $('#expenseError'); e.hidden = true; e.textContent = ''; }
function defaultParticipants(dateStr) {
  const n = C.dayNum(dateStr);
  const present = n === null ? [] : eng().presentChefs(n);
  return present.length ? present : [0, 1, 2, 3, 4];
}
function renderPartChips() {
  $('#partChips').innerHTML = CHEFS.map((n, i) => '<button type="button" class="chip' + (partSel.indexOf(i) >= 0 ? ' on' : '') + '" data-i="' + i + '" aria-pressed="' + (partSel.indexOf(i) >= 0) + '">' + (partSel.indexOf(i) >= 0 ? ico('check', 'sm') : '') + esc(n.split(' ')[0]) + '</button>').join('');
  const k = partSel.length;
  $('#partHint').textContent = k === N ? 'Everyone shares the cost equally.' : k === 0 ? 'Select at least one chef.' : k + ' of ' + N + ' share the cost equally.';
}
function openExpenseModal(id) {
  if (sheetBusy) return;
  const e = id ? state.expenses.filter((x) => x.id === id)[0] : null;
  if (id && !e) return;
  expenseEditId = id || null;
  $('#expenseModalTitle').textContent = e ? 'Edit expense' : 'Add expense';
  $('#expenseDate').value = e ? e.date : iso(selectedDate);
  $('#payerRows').innerHTML = '';
  hideExpenseError();
  if (e && e.payments.length) e.payments.forEach((p) => addPayerRow(p.chef, p.items)); else addPayerRow(null, []);
  partSel = e ? C.participantsOf(e) : defaultParticipants($('#expenseDate').value);
  partTouched = !!e;
  renderPartChips();
  updateExpensePreview();
  openSheet($('#expenseModal'));
}
function addPayerRow(chef, items) {
  const row = document.createElement('div');
  row.className = 'payer-block';
  row.innerHTML = '<div class="payer-row-head"><select class="payer-chef" aria-label="Payer"><option value="">Select payer</option>' + CHEFS.map((n, i) => '<option value="' + i + '"' + (chef === i ? ' selected' : '') + '>' + esc(n) + '</option>').join('') + '</select><button type="button" class="remove-payer ghost danger-text" aria-label="Remove payer">' + ico('close', 'sm') + '</button></div><div class="item-list"></div><button type="button" class="add-item ghost">' + ico('plus', 'sm') + 'Add item</button><div class="payer-total"><span>Payer total</span><b>\u20B90</b></div>';
  const list = row.querySelector('.item-list');
  (items && items.length ? items : [{ label: '', amount: '' }]).forEach((x) => addItemRow(list, x.label, x.amount));
  row.querySelector('.remove-payer').onclick = () => {
    if ($$('.payer-block').length > 1) { row.remove(); hideExpenseError(); updateExpensePreview(); } else toast('Keep at least one payer');
  };
  row.querySelector('.add-item').onclick = () => { addItemRow(list, '', ''); updateExpensePreview(); list.lastElementChild.querySelector('input').focus(); };
  row.addEventListener('input', () => { row.classList.remove('invalid'); hideExpenseError(); updateExpensePreview(); });
  $('#payerRows').appendChild(row);
  updateExpensePreview();
}
function addItemRow(list, label, amount) {
  const row = document.createElement('div');
  row.className = 'item-row';
  row.innerHTML = '<input class="item-label" type="text" maxlength="80" placeholder="Item" value="' + esc(label || '') + '" aria-label="Expense item"><input class="item-amount" type="number" min="0.01" step="0.01" inputmode="decimal" placeholder="Amount" value="' + (amount !== '' && amount !== undefined ? esc(amount) : '') + '" aria-label="Item amount"><button type="button" class="remove-item ghost" aria-label="Remove item">' + ico('close', 'sm') + '</button>';
  row.querySelector('.remove-item').onclick = () => {
    if (list.children.length > 1) row.remove(); else { row.querySelector('.item-label').value = ''; row.querySelector('.item-amount').value = ''; }
    updateExpensePreview();
  };
  list.appendChild(row);
}
function collectPayments() {
  const payments = [], errors = [], seen = {};
  $$('.payer-block').forEach((block) => {
    const chefVal = block.querySelector('.payer-chef').value, items = [];
    let msg = '';
    block.querySelectorAll('.item-row').forEach((row) => {
      const label = row.querySelector('.item-label').value.trim(), raw = row.querySelector('.item-amount').value, amount = C.normalizeAmount(raw);
      if (label && !(amount > 0)) msg = msg || 'Add an amount for \u201C' + label + '\u201D.';
      else if (amount > 0) items.push({ label: (label || 'Kitchen item').slice(0, 80), amount: amount });
      else if (raw !== '') msg = msg || 'Amounts must be greater than \u20B90.';
    });
    if (!msg) {
      if (!chefVal && items.length) msg = 'Choose who paid for these items.';
      else if (chefVal && !items.length) msg = 'Add at least one item for ' + CHEFS[Number(chefVal)] + ', or remove this payer.';
      else if (chefVal && seen[chefVal]) msg = CHEFS[Number(chefVal)] + ' appears twice. Combine their items under one payer.';
    }
    if (chefVal) seen[chefVal] = true;
    if (msg) errors.push({ block: block, msg: msg });
    else if (chefVal && items.length) payments.push({ chef: Number(chefVal), items: items });
  });
  return { payments: payments, errors: errors };
}
function updateExpensePreview() {
  const payments = collectPayments().payments;
  const totalP = payments.reduce((s, p) => s + p.items.reduce((a, x) => a + toP(x.amount), 0), 0);
  $('#liveExpenseTotal').textContent = money(totalP / 100);
  const k = partSel.length || N;
  $('#liveExpenseHint').textContent = totalP > 0 ? payments.length + ' ' + plural(payments.length, 'payer', 'payers') + ' \u00B7 about ' + money(totalP / k / 100) + ' each' : 'Add a payer and at least one item.';
  $$('.payer-block').forEach((b) => {
    let p = 0;
    b.querySelectorAll('.item-amount').forEach((x) => { p += toP(C.normalizeAmount(x.value)); });
    b.querySelector('.payer-total b').textContent = money(p / 100);
  });
}
function submitExpense(ev) {
  ev.preventDefault();
  const date = $('#expenseDate').value;
  if (C.dayNum(date) === null) { showExpenseError('Choose a valid date.'); return; }
  const res = collectPayments();
  $$('.payer-block').forEach((b) => b.classList.remove('invalid'));
  if (res.errors.length) {
    res.errors.forEach((x) => x.block.classList.add('invalid'));
    showExpenseError(res.errors[0].msg);
    if (res.errors[0].block.scrollIntoView) res.errors[0].block.scrollIntoView({ block: 'nearest' });
    return;
  }
  if (!res.payments.length) { showExpenseError('Add a payer and at least one item.'); return; }
  if (!partSel.length) { showExpenseError('Select at least one chef who ate.'); return; }
  const amount = res.payments.reduce((s, p) => s + p.items.reduce((a, x) => a + toP(x.amount), 0), 0) / 100;
  const idx = expenseEditId ? state.expenses.findIndex((x) => x.id === expenseEditId) : -1;
  const old = idx >= 0 ? state.expenses[idx] : null;
  const item = {
    id: old ? old.id : C.newId(), date: date, amount: amount, payments: res.payments,
    participants: partSel.slice().sort((a, b) => a - b), createdAt: old ? old.createdAt : new Date().toISOString()
  };
  if (idx >= 0) state.expenses[idx] = item; else state.expenses.push(item);
  selectedDate = parseDate(date);
  closeSheet($('#expenseModal'), () => { expenseEditId = null; });
  commit('money');
  toast(old ? 'Expense updated' : 'Expense added');
}
function deleteExpense(id) {
  const i = state.expenses.findIndex((x) => x.id === id);
  if (i < 0) return;
  const removed = state.expenses.splice(i, 1)[0];
  commit('money');
  toast(money(removed.amount) + ' expense deleted', { action: 'Undo', onAction: () => { state.expenses.splice(Math.min(i, state.expenses.length), 0, removed); commit('money'); } });
}

/* ---------- off day / away sheet ---------- */
function showRangeError(msg) { const e = $('#rangeError'); e.textContent = msg; e.hidden = false; }
function openRangeModal(kind, chef) {
  if (sheetBusy) return;
  rangeKind = kind;
  const away = kind === 'away';
  $('#rangeEyebrow').textContent = 'Schedule';
  $('#rangeTitle').textContent = away ? 'Chef away' : 'Mark off day';
  $('#rangeSub').textContent = away ? 'The next free chef covers, and the swap is paid back when this chef returns.' : 'Nobody cooks. The rotation does not move on these days.';
  $('#rangeChefWrap').hidden = !away;
  $('#rangeToLabel').textContent = away ? 'Back on (optional)' : 'To (optional)';
  $('#rangeChef').innerHTML = CHEFS.map((n, i) => '<option value="' + i + '">' + esc(n) + '</option>').join('');
  $('#rangeChef').value = chef !== undefined ? String(chef) : '0';
  $('#rangeFrom').value = iso(selectedDate);
  $('#rangeTo').value = '';
  $('#rangeNote').value = '';
  $('#rangeNote').placeholder = away ? 'e.g. went home' : 'e.g. Eid, trip, exams';
  $('#rangeError').hidden = true;
  openSheet($('#rangeModal'));
}
function submitRange(ev) {
  ev.preventDefault();
  const from = $('#rangeFrom').value, to = $('#rangeTo').value, note = $('#rangeNote').value.trim().slice(0, 60);
  if (C.dayNum(from) === null) { showRangeError('Choose a valid start date.'); return; }
  if (to && C.dayNum(to) === null) { showRangeError('Choose a valid end date.'); return; }
  if (to && C.dayNum(to) < C.dayNum(from)) { showRangeError('The end date cannot be before the start date.'); return; }
  if (rangeKind === 'off') {
    state.offDays.push({ id: C.newId(), from: from, to: to || from, reason: note });
  } else {
    state.aways.push({ id: C.newId(), chef: Number($('#rangeChef').value), from: from, to: to || null, note: note });
  }
  closeSheet($('#rangeModal'));
  commit('duty');
  toast(rangeKind === 'off' ? 'Off day saved' : CHEFS[state.aways[state.aways.length - 1].chef].split(' ')[0] + ' marked away');
}
function deleteRange(kind, id) {
  const list = kind === 'off' ? state.offDays : state.aways;
  const i = list.findIndex((x) => x.id === id);
  if (i < 0) return;
  const removed = list.splice(i, 1)[0];
  commit('duty');
  toast('Removed', { action: 'Undo', onAction: () => { list.splice(Math.min(i, list.length), 0, removed); commit('duty'); } });
}
function markBack(id) {
  const a = state.aways.filter((x) => x.id === id)[0];
  if (!a) return;
  const yest = C.isoOf(dn(new Date()) - 1), oldTo = a.to;
  if (a.from > yest) {
    const i = state.aways.indexOf(a);
    state.aways.splice(i, 1);
    commit('duty');
    toast('Marked as back', { action: 'Undo', onAction: () => { state.aways.splice(Math.min(i, state.aways.length), 0, a); commit('duty'); } });
    return;
  }
  a.to = yest;
  commit('duty');
  toast(CHEFS[a.chef].split(' ')[0] + ' is back', { action: 'Undo', onAction: () => { a.to = oldTo; commit('duty'); } });
}

/* ---------- settlements ---------- */
function recordSettlement(from, to, amount) {
  from = Number(from); to = Number(to);
  const scope = ledgerMode === 'all' ? 'all' : 'day', amtP = toP(amount);
  if (!C.validChef(from) || !C.validChef(to) || from === to || amtP <= 0) { toast('Invalid settlement'); return; }
  const bal = scope === 'all' ? allBalances() : dailyBalances(selectedDate);
  if (bal[from].balanceP >= 0 || bal[to].balanceP <= 0) { toast('Balances changed. Showing the latest.'); refresh(); return; }
  const maxP = Math.min(-bal[from].balanceP, bal[to].balanceP);
  if (amtP > maxP) { toast('Maximum valid transfer is ' + money(maxP / 100)); refresh(); return; }
  state.settlements.push({ id: C.newId(), date: scope === 'all' ? iso(new Date()) : iso(selectedDate), scope: scope, from: from, to: to, amount: amtP / 100 });
  commit('money');
  toast(CHEFS[from].split(' ')[0] + ' paid ' + CHEFS[to].split(' ')[0] + ' ' + money(amtP / 100));
}
function deleteSettlement(id) {
  const i = state.settlements.findIndex((x) => x.id === id);
  if (i < 0) return;
  const removed = state.settlements.splice(i, 1)[0];
  commit('money');
  toast('Transfer removed', { action: 'Undo', onAction: () => { state.settlements.splice(Math.min(i, state.settlements.length), 0, removed); commit('money'); } });
}
function buildSummary() {
  const all = ledgerMode === 'all';
  const bal = all ? allBalances() : dailyBalances(selectedDate), sug = C.makeSuggestions(bal);
  const lines = ['Chulha Duty hisaab \u2013 ' + (all ? 'all time' : fmt(selectedDate, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }))];
  lines.push('Kitchen spend: ' + money(all ? totalExpenses() : dateTotal(selectedDate)), '', 'Balances:');
  bal.forEach((b) => lines.push(b.name + ': ' + (b.balanceP > 0 ? '+' : '') + money(b.balance) + (b.balanceP > 0 ? ' (gets back)' : b.balanceP < 0 ? ' (owes)' : ' (settled)')));
  lines.push('', sug.length ? 'To settle:' : 'Everyone is settled.');
  sug.forEach((s, i) => lines.push((i + 1) + '. ' + CHEFS[s.from] + ' pays ' + CHEFS[s.to] + ' ' + money(s.amount)));
  return lines.join('\n');
}

/* ---------- photos ---------- */
function loadBitmap(file) {
  if (window.createImageBitmap) {
    return createImageBitmap(file, { resizeWidth: 384, resizeQuality: 'medium' }).catch(() => createImageBitmap(file));
  }
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('bad image')); };
    img.src = url;
  });
}
function handlePhoto(file) {
  const idx = photoTarget;
  photoTarget = null;
  if (!file || idx === null) return;
  loadBitmap(file).then((bmp) => {
    const w = bmp.width, h = bmp.height, s = Math.min(w, h), SIZE = 192;
    const cv = document.createElement('canvas');
    cv.width = SIZE; cv.height = SIZE;
    const ctx = cv.getContext('2d');
    ctx.drawImage(bmp, (w - s) / 2, (h - s) / 2, s, s, 0, 0, SIZE, SIZE);
    if (bmp.close) bmp.close();
    const url = cv.toDataURL('image/jpeg', 0.82);
    if (!/^data:image\/jpeg;base64,/.test(url)) throw new Error('encode');
    photos[idx] = url;
    Store.savePhotos(photos);
    refresh();
    toast('Photo saved');
  }).catch(() => toast('Could not use that image'));
}
function removePhoto(i) {
  const old = photos[i];
  delete photos[i];
  Store.savePhotos(photos);
  refresh();
  toast('Photo removed', { action: 'Undo', onAction: () => { photos[i] = old; Store.savePhotos(photos); refresh(); } });
}

/* ---------- backup ---------- */
function exportBackup() {
  const payload = { app: 'Chulha Duty', version: 5, exportedAt: new Date().toISOString(), state: state, photos: photos };
  Native.shareFile('chulha-duty-backup-' + iso(new Date()) + '.json', JSON.stringify(payload), 'Chulha Duty backup').then((ok) => {
    if (ok === true) { state.lastBackup = iso(new Date()); persist(); refresh(); toast('Backup ready'); }
    else if (ok !== 'cancelled') toast('Could not create the backup');
  });
}
function importBackup(file) {
  if (!file) return;
  const reader = new FileReader();
  reader.onerror = () => toast('Could not read that file');
  reader.onload = () => {
    try {
      const data = JSON.parse(reader.result), incoming = data && data.state ? data.state : data;
      if (!incoming || !Array.isArray(incoming.expenses) || !Array.isArray(incoming.settlements)) throw new Error('invalid');
      const res = C.sanitizeState(incoming);
      const msg = 'Replace current data with this backup?\n\n' + res.state.expenses.length + ' expenses \u00B7 ' + res.state.settlements.length + ' transfers' + (res.skipped ? '\n' + res.skipped + ' unreadable ' + plural(res.skipped, 'record', 'records') + ' will be skipped.' : '');
      if (!confirm(msg)) return;
      res.state.theme = state.theme;
      res.state.perf = state.perf;
      res.state.notify = state.notify;
      state = res.state;
      if (data && data.photos) { photos = C.sanitizePhotos(data.photos); Store.savePhotos(photos); }
      commit('duty');
      toast(res.skipped ? 'Backup restored \u00B7 ' + res.skipped + ' skipped' : 'Backup restored');
    } catch (e) { toast('Invalid backup file'); }
  };
  reader.readAsText(file);
}

/* ---------- notifications ---------- */
function scheduleNotify() { clearTimeout(notifTimer); notifTimer = setTimeout(doNotify, 1500); }
function doNotify() {
  if (!Native.isNative || !Native.notifSupported()) return;
  if (!state.notify.on) { Native.notifReplace([]); return; }
  Native.notifPermission().then((p) => {
    if (p !== 'granted') { setNotifStatus('denied'); return; }
    const hm = state.notify.time.split(':'), e = eng(), t0 = dn(new Date()), now = Date.now(), items = [];
    for (let k = 0; k < 45; k++) {
      const d = t0 + k, r = e.dutyFor(d);
      if (r.off) continue;
      const p3 = C.isoOf(d).split('-');
      const at = new Date(+p3[0], +p3[1] - 1, +p3[2], +hm[0], +hm[1], 0, 0);
      if (at.getTime() <= now + 30000) continue;
      items.push({ id: d, at: at, title: 'Chulha duty today', body: C.dutyText(r) });
    }
    Native.notifReplace(items);
  });
}

/* ---------- wiring ---------- */
function wire() {
  $$('[data-page]').forEach((b) => b.addEventListener('click', () => openPage(b.dataset.page)));
  $('#prevDay').onclick = () => shiftDate(-1); $('#nextDay').onclick = () => shiftDate(1);
  $('#ledgerPrev').onclick = () => shiftDate(-1); $('#ledgerNext').onclick = () => shiftDate(1);
  $('#todayBtn').onclick = setToday;
  $('#scheduleToday').onclick = () => { setToday(); openPage('home'); };
  $('#schedulePrev').onclick = () => shiftMonth(-1); $('#scheduleNext').onclick = () => shiftMonth(1);
  $('#pickDate').onclick = () => { const i = $('#jumpDate'); i.value = iso(selectedDate); try { i.showPicker(); } catch (e) { i.focus(); i.click(); } };
  $('#jumpDate').addEventListener('change', (e) => { const d = parseDate(e.target.value); if (d) { selectedDate = d; refresh(); } });
  $('#themeBtn').onclick = () => { state.theme = isDark() ? 'light' : 'dark'; persist(); applyTheme(); renderSettings(); };
  $$('.theme-options button[data-theme-choice]').forEach((b) => { b.onclick = () => { state.theme = b.dataset.themeChoice; persist(); applyTheme(); toast('Theme updated'); }; });
  $$('#perfOptions button').forEach((b) => { b.onclick = () => { state.perf = b.dataset.perf; persist(); applyPerf(); renderSettings(); toast('Performance mode updated'); }; });
  $('#dayLedgerBtn').onclick = () => { ledgerMode = 'day'; renderHisaab(); };
  $('#allLedgerBtn').onclick = () => { ledgerMode = 'all'; renderHisaab(); };
  $('#viewHisaab').onclick = () => { ledgerMode = 'day'; openPage('hisaab'); };
  $('#hisaabShare').onclick = () => { Native.shareText('Chulha Duty hisaab', buildSummary()).then((r) => { if (r === 'copied') toast('Summary copied'); }); };
  $('#saveSettings').onclick = () => {
    const date = $('#startDate').value;
    if (C.dayNum(date) === null) { toast('Choose a valid start date'); return; }
    state.startDate = date; state.startPair = Number($('#startPair').value);
    commit('duty'); toast('Rotation saved');
  };
  $('#weekdayChips').addEventListener('click', (e) => {
    const b = e.target.closest('.chip.day'); if (!b) return;
    const d = Number(b.dataset.day), i = state.weeklyOff.indexOf(d);
    if (i >= 0) state.weeklyOff.splice(i, 1); else state.weeklyOff.push(d);
    commit('duty');
  });
  $('#notifToggle').addEventListener('change', (e) => {
    const on = e.target.checked;
    if (!on) { state.notify.on = false; persist(); setNotifStatus('off'); doNotify(); return; }
    Native.notifRequest().then((p) => {
      if (p === 'granted') { state.notify.on = true; persist(); setNotifStatus('on'); doNotify(); toast('Reminder is on'); }
      else { e.target.checked = false; state.notify.on = false; persist(); setNotifStatus('denied'); }
    });
  });
  $('#notifTime').addEventListener('change', (e) => { if (/^\d{2}:\d{2}$/.test(e.target.value)) { state.notify.time = e.target.value; persist(); scheduleNotify(); toast('Reminder time saved'); } });
  $('#resetBtn').onclick = () => {
    if (!confirm('Reset rotation to 2 October 2026 and delete all expenses, settlements, off days and away records? This cannot be undone.')) return;
    const keep = { theme: state.theme, perf: state.perf, notify: state.notify };
    state = Object.assign(C.defaultState(), keep);
    selectedDate = localNoon(new Date());
    commit('duty'); toast('Everything reset');
  };
  $('#exportBackup').onclick = exportBackup;
  $('#nudgeBtn').onclick = exportBackup;
  $('#importBackup').onchange = (e) => { importBackup(e.target.files[0]); e.target.value = ''; };
  $('#addExpense').onclick = () => openExpenseModal(); $('#hisaabAdd').onclick = () => openExpenseModal();
  $('#qaOff').onclick = () => openRangeModal('off'); $('#qaAway').onclick = () => openRangeModal('away');
  $('#addOffBtn').onclick = () => openRangeModal('off'); $('#addAwayBtn').onclick = () => openRangeModal('away');
  const closeExp = () => closeSheet($('#expenseModal'), () => { expenseEditId = null; });
  $('#closeExpense').onclick = closeExp; $('#cancelExpense').onclick = closeExp;
  $('#closeRange').onclick = () => closeSheet($('#rangeModal')); $('#cancelRange').onclick = () => closeSheet($('#rangeModal'));
  $('#addPayer').onclick = () => { addPayerRow(null, []); const last = $('#payerRows').lastElementChild; if (last.scrollIntoView) last.scrollIntoView({ block: 'nearest' }); };
  $('#expenseForm').addEventListener('submit', submitExpense);
  $('#rangeForm').addEventListener('submit', submitRange);
  $('#rangeForm').addEventListener('input', () => { $('#rangeError').hidden = true; });
  $('#expenseDate').addEventListener('input', () => {
    hideExpenseError();
    if (!partTouched) { partSel = defaultParticipants($('#expenseDate').value); renderPartChips(); updateExpensePreview(); }
  });
  $('#partChips').addEventListener('click', (e) => {
    const b = e.target.closest('.chip'); if (!b) return;
    const i = Number(b.dataset.i), k = partSel.indexOf(i);
    if (k >= 0) partSel.splice(k, 1); else partSel.push(i);
    partTouched = true; hideExpenseError(); renderPartChips(); updateExpensePreview();
  });
  $('#partAll').onclick = () => { partSel = [0, 1, 2, 3, 4]; partTouched = true; renderPartChips(); updateExpensePreview(); };
  backdropClose($('#expenseModal'), closeExp);
  backdropClose($('#rangeModal'), () => closeSheet($('#rangeModal')));
  $('#photoInput').addEventListener('change', (e) => { handlePhoto(e.target.files[0]); e.target.value = ''; });

  document.addEventListener('click', (e) => {
    const t = e.target;
    let b;
    if ((b = t.closest('.edit-expense'))) return openExpenseModal(b.dataset.id);
    if ((b = t.closest('.delete-expense'))) return deleteExpense(b.dataset.id);
    if ((b = t.closest('.record-settle'))) return recordSettlement(b.dataset.from, b.dataset.to, b.dataset.amount);
    if ((b = t.closest('.delete-settle'))) return deleteSettlement(b.dataset.id);
    if ((b = t.closest('.delete-range'))) return deleteRange(b.dataset.kind, b.dataset.id);
    if ((b = t.closest('.back-away'))) return markBack(b.dataset.id);
    if ((b = t.closest('.add-away'))) return openRangeModal('away', Number(b.dataset.chef));
    if ((b = t.closest('.photo-btn'))) { photoTarget = Number(b.dataset.chef); $('#photoInput').click(); return; }
    if ((b = t.closest('.rm-photo'))) return removePhoto(Number(b.dataset.chef));
    if (t.closest('.add-expense-btn')) return openExpenseModal();
    const day = t.closest('.duty-row.as-btn');
    if (day) { const d = parseDate(day.dataset.date); if (d) { selectedDate = d; refresh(); openPage('home'); } }
  });

  Native.onBack(() => {
    if (closeTopSheet()) return;
    if (activePage !== 'home') { openPage('home'); return; }
    Native.exitApp();
  });
  Native.onVisibility((active) => {
    if (!active) { Store.flush(); return; }
    const now = iso(new Date());
    if (now !== todayIso) {
      if (iso(selectedDate) === todayIso) selectedDate = localNoon(new Date());
      todayIso = now;
      refresh();
    }
    scheduleNotify();
  });
  if (window.matchMedia) {
    const mq = matchMedia('(prefers-color-scheme: dark)');
    const onChange = () => { if (state.theme === 'system') applyTheme(); };
    if (mq.addEventListener) mq.addEventListener('change', onChange); else if (mq.addListener) mq.addListener(onChange);
  }
}

/* ---------- boot ---------- */
function boot() {
  wire();
  Store.setFailHandler(() => toast('Could not save to phone storage'));
  Store.init().then((r) => {
    if (r.state) state = C.sanitizeState(r.state).state;
    photos = C.sanitizePhotos(r.photos);
  }).catch(() => { }).then(() => {
    applyTheme();
    applyPerf();
    refresh();
    scheduleNotify();
    requestAnimationFrame(() => { Native.hideSplash(); });
  });
}
boot();
})();
