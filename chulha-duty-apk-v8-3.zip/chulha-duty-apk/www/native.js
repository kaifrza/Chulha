(function () {
  'use strict';

  var isNative = false;
  try { isNative = !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()); } catch (e) { }
  var cache = {};

  function plugin(name) {
    if (!isNative) return null;
    if (cache[name] !== undefined) return cache[name];
    var p = null;
    try {
      var c = window.Capacitor;
      p = (c.Plugins && c.Plugins[name]) || (c.registerPlugin ? c.registerPlugin(name) : null);
    } catch (e) { p = null; }
    cache[name] = p;
    return p;
  }
  function safe(fn) { try { return Promise.resolve(fn()).catch(function () { return null; }); } catch (e) { return Promise.resolve(null); } }

  var CHANNEL = 'duty';
  var channelReady = false;

  window.Native = {
    isNative: isNative,

    hideSplash: function () {
      var s = plugin('SplashScreen');
      return s ? safe(function () { return s.hide({ fadeOutDuration: 250 }); }) : Promise.resolve();
    },
    setStatusBar: function (dark, color) {
      var s = plugin('StatusBar');
      if (!s) return;
      safe(function () { return s.setOverlaysWebView({ overlay: false }); });
      safe(function () { return s.setStyle({ style: dark ? 'DARK' : 'LIGHT' }); });
      safe(function () { return s.setBackgroundColor({ color: color }); });
    },
    onBack: function (handler) {
      var a = plugin('App');
      if (a) a.addListener('backButton', handler);
    },
    exitApp: function () {
      var a = plugin('App');
      if (a) safe(function () { return a.exitApp(); });
    },
    onVisibility: function (cb) {
      document.addEventListener('visibilitychange', function () { cb(!document.hidden); });
      var a = plugin('App');
      if (a) a.addListener('appStateChange', function (s) { cb(!!s.isActive); });
    },

    /* ----- share ----- */
    shareText: function (title, text) {
      var s = plugin('Share');
      if (s) return safe(function () { return s.share({ title: title, text: text, dialogTitle: title }); }).then(function (r) { return r !== null; });
      if (navigator.share) return navigator.share({ title: title, text: text }).then(function () { return true; }).catch(function () { return false; });
      return navigator.clipboard && navigator.clipboard.writeText
        ? navigator.clipboard.writeText(text).then(function () { return 'copied'; }).catch(function () { return false; })
        : Promise.resolve(false);
    },
    shareFile: function (filename, text, title) {
      var fs = plugin('Filesystem'), s = plugin('Share');
      if (fs && s) {
        return fs.writeFile({ path: filename, data: text, directory: 'CACHE', encoding: 'utf8' })
          .then(function () { return fs.getUri({ path: filename, directory: 'CACHE' }); })
          .then(function (r) { return s.share({ title: title, files: [r.uri], dialogTitle: title }); })
          .then(function () { return true; })
          .catch(function () { return false; });
      }
      try {
        var url = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
        var a = document.createElement('a');
        a.href = url; a.download = filename;
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
        return Promise.resolve(true);
      } catch (e) { return Promise.resolve(false); }
    },

    /* ----- notifications ----- */
    notifSupported: function () { return !!plugin('LocalNotifications'); },
    notifPermission: function () {
      var n = plugin('LocalNotifications');
      if (!n) return Promise.resolve('unsupported');
      return n.checkPermissions().then(function (r) { return r.display; }).catch(function () { return 'denied'; });
    },
    notifRequest: function () {
      var n = plugin('LocalNotifications');
      if (!n) return Promise.resolve('unsupported');
      return n.requestPermissions().then(function (r) { return r.display; }).catch(function () { return 'denied'; });
    },
    /* items: [{id, at:Date, title, body}] — replaces everything scheduled before */
    notifReplace: function (items) {
      var n = plugin('LocalNotifications');
      if (!n) return Promise.resolve(false);
      var chain = Promise.resolve();
      if (!channelReady) {
        chain = chain.then(function () {
          return n.createChannel({ id: CHANNEL, name: 'Duty reminders', description: 'Daily chulha duty reminder', importance: 4, visibility: 1, vibration: true });
        }).then(function () { channelReady = true; }).catch(function () { channelReady = true; });
      }
      return chain.then(function () { return n.getPending(); }).then(function (p) {
        var list = (p && p.notifications) || [];
        return list.length ? n.cancel({ notifications: list.map(function (x) { return { id: x.id }; }) }) : null;
      }).then(function () {
        if (!items.length) return true;
        return n.schedule({
          notifications: items.map(function (i) {
            return {
              id: i.id, title: i.title, body: i.body, channelId: CHANNEL,
              schedule: { at: i.at, allowWhileIdle: true },
              smallIcon: 'ic_stat_flame', iconColor: '#ff9a3d'
            };
          })
        }).then(function () { return true; });
      }).catch(function () { return false; });
    }
  };
})();
