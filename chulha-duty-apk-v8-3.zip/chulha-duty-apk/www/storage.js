(function () {
  'use strict';

  function plugin(name) {
    try {
      var c = window.Capacitor;
      if (!c) return null;
      if (c.Plugins && c.Plugins[name]) return c.Plugins[name];
      return c.registerPlugin ? c.registerPlugin(name) : null;
    } catch (e) { return null; }
  }
  var isNative = false;
  try { isNative = !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()); } catch (e) { }
  var FS = isNative ? plugin('Filesystem') : null;
  var useFiles = !!FS;

  var LS_STATE = 'chulhaState', LS_PHOTOS = 'chulhaPhotos';

  /* Two alternating files: a crash in the middle of a write can never destroy the last good copy. */
  function Slotted(prefix, lsKey) {
    var seq = 0, queue = Promise.resolve();

    function readFile(name) {
      return FS.readFile({ path: name, directory: 'DATA', encoding: 'utf8' }).then(function (r) {
        var o = JSON.parse(r.data);
        return o && typeof o.seq === 'number' && 'data' in o ? o : null;
      }).catch(function () { return null; });
    }
    this.load = function () {
      if (!useFiles) {
        try {
          var raw = localStorage.getItem(lsKey);
          return Promise.resolve(raw ? JSON.parse(raw) : null);
        } catch (e) { return Promise.resolve(null); }
      }
      return Promise.all([readFile(prefix + '_a.json'), readFile(prefix + '_b.json')]).then(function (r) {
        var list = r.filter(Boolean).sort(function (a, b) { return b.seq - a.seq; });
        if (list.length) seq = list[0].seq;
        return list.length ? list[0].data : null;
      });
    };
    this.write = function (data) {
      queue = queue.then(function () {
        if (!useFiles) {
          try { localStorage.setItem(lsKey, JSON.stringify(data)); return true; } catch (e) { return false; }
        }
        seq++;
        var name = prefix + (seq % 2 === 0 ? '_a.json' : '_b.json');
        return FS.writeFile({
          path: name, directory: 'DATA', encoding: 'utf8', recursive: true,
          data: JSON.stringify({ seq: seq, savedAt: Date.now(), data: data })
        }).then(function () { return true; }).catch(function () { return false; });
      });
      return queue;
    };
  }

  var stateStore = new Slotted('state', LS_STATE);
  var photoStore = new Slotted('photos', LS_PHOTOS);
  var timer = null, latest = null, onFail = null;

  function flush() {
    clearTimeout(timer);
    timer = null;
    if (!latest) return Promise.resolve(true);
    var data = latest;
    latest = null;
    return stateStore.write(data).then(function (ok) {
      if (!ok && onFail) onFail();
      return ok;
    });
  }

  window.Store = {
    isNative: isNative,
    usesFiles: useFiles,
    init: function () {
      return Promise.all([stateStore.load(), photoStore.load()]).then(function (r) {
        return { state: r[0], photos: r[1] };
      });
    },
    /* debounced: UI never waits for disk */
    save: function (state) {
      latest = state;
      clearTimeout(timer);
      timer = setTimeout(flush, 350);
    },
    flush: flush,
    savePhotos: function (photos) { return photoStore.write(photos); },
    setFailHandler: function (fn) { onFail = fn; }
  };
})();
